
from numpy import genfromtxt
import numpy as np 
from sklearn.model_selection import *
from sklearn import svm 
from sklearn.model_selection import cross_val_score
import sklearn.preprocessing as preproc
import matplotlib.pyplot as plt
import seaborn as sns

X_train = genfromtxt('../Datasets/Train_features', delimiter=',')
X_test = genfromtxt('../Datasets/Test_features', delimiter=',')
y_train = genfromtxt('../Datasets/Train_labels', delimiter=',')
y_test = genfromtxt('../Datasets/Test_labels', delimiter=',')

X_train = np.reshape(X_train,(1006,96))
X_train = preproc.scale(X_train)
X_test = np.reshape(X_test,(80,96))
X_test = preproc.scale(X_test)


kernel_exp_parameter = {'C':[1e-4,1e-3,1e-2,1e-1,1,10]}
svc = svm.SVC(kernel='linear', verbose=True)
clf = GridSearchCV(svc, kernel_exp_parameter, cv=10, n_jobs=16)
clf.fit(X_train, y_train)

# kernel_lin_parameter = {'C':np.linspace(1e-4,1e-2,num=100)}
# clf = GridSearchCV(svc, kernel_lin_parameters, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

# kernel_exp_parameter = {'C':[1e-4,1e-3,1e-2,1e-1,1,10], 'gamma':[1e-5,1e-3,1e-2,1e-1,1,10]}
#svc = svm.SVC(kernel='rbf', verbose=True)
# clf = GridSearchCV(svc, kernel_exp_parameter, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

# kernel_lin_parameter = {'C':np.linspace(1e-1,10,num=10), 'gamma':np.linspace(1e-4,1e-2,num=10)}
# clf = GridSearchCV(svc, kernel_lin_parameter, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

# kernel_exp_parameter = {'C':[1e-4,1e-3,1e-2,1e-1,1,10], 'degree':[1,2,3,4,5,6]}
# svc = svm.SVC(kernel='poly', verbose=True)
# clf = GridSearchCV(svc, kernel_exp_parameter, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

# kernel_lin_parameter = {'C':np.linspace(1e-1,1,num=10), 'degree':[1,2,3,4,5,6,7,8,9,10]}
# clf = GridSearchCV(svc, kernel_lin_parameter, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

# kernel_exp_parameter = {'C':[1e-4,1e-3,1e-2,1e-1,1,10], 'gamma':[1e-5,1e-3,1e-2,1e-1,1], 'r':[0,12,3,4,5,6]}
# svc = svm.SVC(kernel='sigmoid', verbose=True)
# clf = GridSearchCV(svc, kernel_exp_parameter, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

# kernel_lin_parameter = {'C':np.linspace(1e-5,1e-3,num=10), 'gamma':np.linspace(1e-5,1e-3,num=10), 'r':[0,1,2,3,4,5,6,7,8,9,10]}
# clf = GridSearchCV(svc, kernel_lin_parameter, cv=10, n_jobs=16)
# clf.fit(X_train, y_train)

scores = clf.grid_scores_

y_plot_scores = []
for i in range(0,len(scores)):
	y_plot_scores.append(scores[i][1])
plt.plot((np.log10(kernel_exp_parameter['C']), y_plot_scores))

# y_plot_scores = []
# for i in range(0,len(scores)):
# 	y_plot_scores.append(scores[i][1])

# for j in range(0,len(kernel_lin_parameter['C'])):
# 	y_plot = y_plot_scores[6*j:6*(j+1)]
# 	x_plot = ((kernel_lin_parameter['degree']))
# 	plt.plot(x_plot,y_plot,label = " C = " + str(kernel_lin_parameter['C'][j]))


# for j in range(0,len(kernel_lin_parameter['C'])):
# 	y_plot = y_plot_scores[10*j:10*(j+1)]
# 	x_plot = (kernel_lin_parameter['gamma'])
# 	plt.plot(x_plot,y_plot,label = str(linkernel_lin_parameter['C'][j]))

print "The best Parameters are:" + str(clf.best_params_)
plt.legend()
plt.xlabel('Degree')
plt.ylabel('Mean score')
plt.show()