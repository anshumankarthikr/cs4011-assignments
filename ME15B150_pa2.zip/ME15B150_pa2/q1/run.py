#Importing relevant libraries
import pandas as pd 
from sklearn.decomposition import PCA
import sklearn.preprocessing as preproc
from sklearn.linear_model import LinearRegression
import sklearn.metrics as met 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
#Importing relevant datasets
X_train = pd.read_csv('../Datasets/train.csv', header=None)
y_train = pd.read_csv('../Datasets/train_labels.csv', header=None)
X_test = pd.read_csv('../Datasets/test.csv', header=None)
y_test = pd.read_csv('../Datasets/test_labels.csv', header=None)

#Color
colors=[]
for i in range(len(X_train[0])):
	if y_train[0][i] == 1:
		colors.append('r')
	else:
		colors.append('b')

#Normalizing the data
X_train = preproc.scale(X_train)
X_test = preproc.scale(X_test)

#Running PCA on the data
pca = PCA(n_components=1)
X_train_pca = pca.fit_transform(X_train)
X_test_pca = pca.fit_transform(X_test)

#Running a linear Regression Classifier on the data
linreg = LinearRegression()
linreg.fit(X_train_pca, y_train)
y_predict = linreg.predict(X_test_pca)

linreg2 = LinearRegression()
linreg2.fit(X_train,y_train)
y_predict2 = linreg2.predict(X_test)


for i in y_predict:
	if i[0] <1.5:
		i[0] = 1;
	else:
		i[0] = 2;

for i in y_predict2:
	if i[0] <1.5:
		i[0] = 1;
	else:
		i[0] = 2;

print 
print "Linear Regression (before PCA): "
print "Accuracy: " + str(met.accuracy_score(y_test,y_predict2))
print "Precision:" + str(met.precision_score(y_test,y_predict2,pos_label=1))
print "Recall Score: " + str(met.recall_score(y_test,y_predict2,pos_label=1))
print "F-Measure: " + str(met.f1_score(y_test,y_predict2,pos_label=1))
print
print "Linear Regression (after PCA): "
print "Accuracy: " + str(met.accuracy_score(y_test,y_predict))
print "Precision:" + str(met.precision_score(y_test,y_predict,pos_label=1))
print "Recall Score: " + str(met.recall_score(y_test,y_predict,pos_label=1))
print "F-Measure: " + str(met.f1_score(y_test,y_predict,pos_label=1))

#Plotting in the 3D subspace


# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# colors = []
# for i in range(len(X_train[0])):
# 	if y_train[0][i] == 1:
# 		colors.append('r')
# 	else:
# 		colors.append('b')
# ax.scatter(X_train[0], X_train[1],X_train[2], c=colors)
# ax.hold(True)
# w = linreg2.coef_
# p = pca.components_
# x, y = np.meshgrid(range(-3,4), range(-3,6))
# z = (1.5-linreg2.intercept_-w[0][0]*x -w[0][1]*y)/w[0][2]
# ax.plot_surface(x,y,z,alpha=0.2)
plt.show()

#Plotting the DataSet in the PCA Space
plt.scatter(X_train_pca,np.zeros_like(X_train_pca),c=colors, alpha=0.1)
yy = np.linspace(-5, 5)
xx = []
for i in range(len(yy)):
	xx.append(linreg.coef_[0][0]) 
plt.plot(xx, yy , 'k-')
plt.show()


