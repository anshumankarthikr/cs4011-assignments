import pandas as pd 
import numpy as np 
from sklearn.lda import LDA 
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sklearn.preprocessing as preproc
import sklearn.metrics as met 

X = pd.read_csv('../Datasets/iris.data', header=None)
X.columns = ['sepal-length','sepal-width','petal-length','petal-width', 'iris-type']
X = X.drop(['sepal-length','sepal-width'], axis=1)
y_train = []
for i in X['iris-type']:
	if i == 'Iris-setosa':
		y_train.append(1)
	if i == 'Iris-versicolor':
		y_train.append(0)
	if i == 'Iris-virginica':
		y_train.append(-1)

X_train = X.drop(['iris-type'], axis=1)
X_train = preproc.scale(X_train)
X_train = pd.DataFrame(X_train)
X_train.columns = ['petal-length', 'petal-width']
colors = list()
for i in range(150):
	if y_train[i] == 1:
		colors.append('r')
	if y_train[i] == 0:
		colors.append('b')
	if y_train[i] == -1:
		colors.append('g')


#Plotting the 3D Data
plt.scatter(X_train['petal-length'], X_train['petal-width'], c=colors, s=14)
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')
plt.show()

#Performing LDA
# lda = LDA(n_components=1)
# X_train_lda = lda.fit_transform(X_train,y_train)

# #Plotting LDA in the 2D Subspace
# plt.scatter(X_train_lda,np.zeros_like(X_train_lda),c=colors, alpha=0.3)
# plt.hold(True)
# w = lda.coef_[1]
# a = -w[0] / w[1]
# xx = np.linspace(-5, 5)
# yy1 = a * xx - (lda.intercept_[0]) / w[1] 
# plt.plot(xx, yy1, 'k-')
# plt.hold(True)
# w = lda.coef_[2]
# a = -w[1] / w[1]
# xx = np.linspace(-5, 5)
# yy2 = a * xx - (lda.intercept_[2]) / w[1] 
# plt.plot(xx, yy2, 'k-')
# plt.show()

# y_predict = lda.predict(X_train)
# #LDA Prediction 
# print "LDA Analysis:"
# print "Accuracy: " + str(met.accuracy_score(y_train,y_predict))
# print "Precision: " + str(met.precision_score(y_train,y_predict,average='macro',pos_label=-1))
# print "Recall Score: " + str(met.recall_score(y_train,y_predict,average='macro',pos_label=-1))
# print "F-Measure: " + str(met.f1_score(y_train,y_predict,average='macro',pos_label=-1))
#Performing QDA
X_train = preproc.scale(X_train)
qda = QuadraticDiscriminantAnalysis()
Z = qda.desicion_function(X_train,y_train)
x_min, x_max = np.min(X_train[:, 0]) - .5, np.max(X_train[:, 0]) + .5
y_min, y_max = np.min(X_train[:, 1]) - .5, np.max(X_train[:, 1]) + .5
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
np.arange(y_min, y_max, h))
X_train = pd.DataFrame(X_train)
X_train.columns = ['petal-length', 'petal-width']
plt.scatter(X_train['petal-length'], X_train['petal-width'], c=colors, s=14)
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')
plt.show()

#QDA Performance
y_predict = qda.predict(X_train)
print "QDA Analysis:"
print "Accuracy: " + str(met.accuracy_score(y_train,y_predict))
print "Precision: " + str(met.precision_score(y_train,y_predict,average='macro',pos_label=1))
print "Recall Score: " + str(met.recall_score(y_train,y_predict,average='macro',pos_label=1))
print "F-Measure: " + str(met.f1_score(y_train,y_predict,average='macro',pos_label=1))
#Performing QDA

# print qda.getparams()

