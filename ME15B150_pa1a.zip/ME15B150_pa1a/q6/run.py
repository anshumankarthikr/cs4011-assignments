#STEP 0: Importing relevant libraries

import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.feature_selection import SelectFromModel

#STEP 1: Importing Relevant Datasets

train = pd.read_csv('../Datasets/CandC-train1.csv')
test = pd.read_csv('../Datasets/CandC-test1.csv')

y_train1 = train.iloc[:,-1]
del train['127']
X_train1 = train
y_test1 = test.iloc[:,-1]
del test['127']
X_test1 = test

train = pd.read_csv('../Datasets/CandC-train2.csv')
test = pd.read_csv('../Datasets/CandC-test2.csv')
y_train2 = train.iloc[:,-1]
del train['127']
X_train2 = train
y_test2 = test.iloc[:,-1]
del test['127']
X_test2 = test

train = pd.read_csv('../Datasets/CandC-train3.csv')
test = pd.read_csv('../Datasets/CandC-test3.csv')
y_train3 = train.iloc[:,-1]
del train['127']
X_train3 = train
y_test3 = test.iloc[:,-1]
del test['127']
X_test3 = test

train = pd.read_csv('../Datasets/CandC-train4.csv')
test = pd.read_csv('../Datasets/CandC-test4.csv')
y_train4 = train.iloc[:,-1]
del train['127']
X_train4 = train
y_test4 = test.iloc[:,-1]
del test['127']
X_test4 = test

train = pd.read_csv('../Datasets/CandC-train5.csv')
test = pd.read_csv('../Datasets/CandC-test5.csv')
y_train5 = train.iloc[:,-1]
del train['127']
X_train5 = train
y_test5 = test.iloc[:,-1]
del test['127']
X_test5 = test

#STEP 2: Ridge Regression - Finding the Best Value of Lambda

rss = []
# Running a linear search over the parameters over a set of values after a manual peek
for i in range(1,100):
	linreg = Ridge(alpha=i)
	linreg.fit(X_train1,y_train1)
	y_predict1 = linreg.predict(X_test1)
	linreg.fit(X_train2,y_train2)
	y_predict2 = linreg.predict(X_test2)
	linreg.fit(X_train3,y_train3)
	y_predict3 = linreg.predict(X_test3)
	linreg.fit(X_train4,y_train4)
	y_predict4 = linreg.predict(X_test4)
	linreg.fit(X_train5,y_train5)
	y_predict5 = linreg.predict(X_test5)
	rss.append(np.mean([np.linalg.norm(y_test1-y_predict1)**2,np.linalg.norm(y_test2-y_predict2)**2,np.linalg.norm(y_test3-y_predict3)**2,np.linalg.norm(y_test4-y_predict4)**2,np.linalg.norm(y_test5-y_predict5)**2]))

lambda_max = (np.argmin(rss) + 1)
print "The best value of lambda before dropping features is:" + str(lambda_max)

#STEP 3: Ridge Regression for the Maximum Value of Lambda
#coefficients will be saved, code commented out to prevent overwriting
linreg = Ridge(alpha=lambda_max)
linreg.fit(X_train1,y_train1)
#weights = linreg.coef_
#np.savetxt("coeffs1.csv", weights, delimiter=",")
y_predict1 = linreg.predict(X_test1)
linreg.fit(X_train2,y_train2)
#weights = linreg.coef_
#np.savetxt("coeffs2.csv", weights, delimiter=",")
y_predict2 = linreg.predict(X_test2)
linreg.fit(X_train3,y_train3)
#weights = linreg.coef_
#np.savetxt("coeffs3.csv", weights, delimiter=",")
y_predict3 = linreg.predict(X_test3)
linreg.fit(X_train4,y_train4)
#weights = linreg.coef_
#np.savetxt("coeffs4.csv", weights, delimiter=",")
y_predict4 = linreg.predict(X_test4)
linreg.fit(X_train5,y_train5)
weights = linreg.coef_
#npls.savetxt("coeffs5.csv", weights, delimiter=",")
y_predict5 = linreg.predict(X_test5)

print "Ridge Regression without Dropping Features:"
print "Case 1, RSS = " + str(np.linalg.norm(y_test1-y_predict1)**2)
print "Case 2, RSS = " + str(np.linalg.norm(y_test2-y_predict2)**2)
print "Case 3, RSS = " + str(np.linalg.norm(y_test3-y_predict3)**2)
print "Case 4, RSS = " + str(np.linalg.norm(y_test4-y_predict4)**2)
print "Case 5, RSS = " + str(np.linalg.norm(y_test5-y_predict5)**2)
print "Average =" + str(np.mean([np.linalg.norm(y_test1-y_predict1)**2,np.linalg.norm(y_test2-y_predict2)**2,np.linalg.norm(y_test3-y_predict3)**2,np.linalg.norm(y_test4-y_predict4)**2,np.linalg.norm(y_test5-y_predict5)**2]))

#STEP 4: Best Subset Selection
train = pd.read_csv('../Datasets/CandC-train1.csv')
test = pd.read_csv('../Datasets/CandC-test1.csv')
frames = [train,test]
X = pd.concat(frames)
y = X.iloc[:,-1]
del X['127']
linreg = Ridge()
selector = SelectFromModel(linreg, threshold=0.05)
selector.fit(X,y)

X_train1 =selector.transform(X_train1)
X_train1 = pd.DataFrame(X_train1)
X_test1 =selector.transform(X_test1)
X_test1 = pd.DataFrame(X_test1)

X_train2 =selector.transform(X_train2)
X_train2 = pd.DataFrame(X_train2)
X_test2 =selector.transform(X_test2)
X_test2 = pd.DataFrame(X_test2)

X_train3 =selector.transform(X_train3)
X_train3 = pd.DataFrame(X_train3)
X_test3 =selector.transform(X_test3)
X_test3 = pd.DataFrame(X_test3)

X_train4 =selector.transform(X_train4)
X_train4 = pd.DataFrame(X_train4)
X_test4 =selector.transform(X_test4)
X_test4 = pd.DataFrame(X_test4)

X_train5 =selector.transform(X_train5)
X_train5 = pd.DataFrame(X_train5)
X_test5 =selector.transform(X_test5)
X_test5 = pd.DataFrame(X_test5)

rss = []
# Running a linear search over the parameters over a set of values after a manual peek
for i in range(1,100):
	linreg = Ridge(alpha=i)
	linreg.fit(X_train1,y_train1)
	y_predict1 = linreg.predict(X_test1)
	linreg.fit(X_train2,y_train2)
	y_predict2 = linreg.predict(X_test2)
	linreg.fit(X_train3,y_train3)
	y_predict3 = linreg.predict(X_test3)
	linreg.fit(X_train4,y_train4)
	y_predict4 = linreg.predict(X_test4)
	linreg.fit(X_train5,y_train5)
	y_predict5 = linreg.predict(X_test5)
	rss.append(np.mean([np.linalg.norm(y_test1-y_predict1)**2,np.linalg.norm(y_test2-y_predict2)**2,np.linalg.norm(y_test3-y_predict3)**2,np.linalg.norm(y_test4-y_predict4)**2,np.linalg.norm(y_test5-y_predict5)**2]))

lambda_max = (np.argmin(rss) + 1)
print "The best value of lambda after dropping features is:" + str(lambda_max)

#STEP 3: Ridge Regression for the Maximum Value of Lambda
#coefficients will be saved, code commented out to prevent overwriting
linreg = Ridge(alpha=lambda_max)
linreg.fit(X_train1,y_train1)
weights = linreg.coef_
np.savetxt("coeffs1drop.csv", weights, delimiter=",")
y_predict1 = linreg.predict(X_test1)
linreg.fit(X_train2,y_train2)
weights = linreg.coef_
np.savetxt("coeffs2drop.csv", weights, delimiter=",")
y_predict2 = linreg.predict(X_test2)
linreg.fit(X_train3,y_train3)
weights = linreg.coef_
np.savetxt("coeffs3drop.csv", weights, delimiter=",")
y_predict3 = linreg.predict(X_test3)
linreg.fit(X_train4,y_train4)
weights = linreg.coef_
np.savetxt("coeffs4drop.csv", weights, delimiter=",")
y_predict4 = linreg.predict(X_test4)
linreg.fit(X_train5,y_train5)
weights = linreg.coef_
np.savetxt("coeffs5drop.csv", weights, delimiter=",")
y_predict5 = linreg.predict(X_test5)

print "Ridge Regression with Dropping Features:"
print "Case 1, RSS = " + str(np.linalg.norm(y_test1-y_predict1)**2)
print "Case 2, RSS = " + str(np.linalg.norm(y_test2-y_predict2)**2)
print "Case 3, RSS = " + str(np.linalg.norm(y_test3-y_predict3)**2)
print "Case 4, RSS = " + str(np.linalg.norm(y_test4-y_predict4)**2)
print "Case 5, RSS = " + str(np.linalg.norm(y_test5-y_predict5)**2)
print "Average =" + str(np.mean([np.linalg.norm(y_test1-y_predict1)**2,np.linalg.norm(y_test2-y_predict2)**2,np.linalg.norm(y_test3-y_predict3)**2,np.linalg.norm(y_test4-y_predict4)**2,np.linalg.norm(y_test5-y_predict5)**2]))


