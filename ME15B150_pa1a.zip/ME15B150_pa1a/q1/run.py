#STEP 1: Importing relevant libraries

import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split


#STEP 2: Defining means and covariances for the classes

np.random.seed(42) #setting a random seed to ensure constant values

#The means and variances have been set as random values that are close to each other 
mean1 = np.random.uniform(low=-1, high=1,size=20)
mean2 = np.random.uniform(low=-1, high=1,size=20)
covar1 = np.random.uniform(low=1, high=5,size=20)
covar2 = np.random.uniform(low=1, high=5,size=20)

#making the covariance matrices diagonal matrices

covar1 = np.diag(covar1)
covar2 = np.diag(covar2)


#STEP 3: Generating samples from a Mutivariate Gaussian Distribution

ds1 = []
ds1_labels = []  
a = np.ones(1) 
#generating the dataset and the associated labels
for i in range(0,4000):
	if(i%2==0):
		ds1.append(np.concatenate([a,np.random.multivariate_normal(mean1,covar1)]))
		ds1_labels.append(1)
	else:
		ds1.append(np.concatenate([a,np.random.multivariate_normal(mean2,covar2)]))
		ds1_labels.append(-1)

ds1 = np.array(ds1)
ds1_labels = np.array(ds1_labels)

#STEP 4: Splitting into a 70-30 Test Train Split
X_train, X_test, y_train, y_test = train_test_split(ds1,ds1_labels, test_size=0.3, random_state=42)
dfXtrain=pd.DataFrame(X_train)
dfXtest=pd.DataFrame(X_test)
dfytest=pd.DataFrame(y_test)
dfytrain=pd.DataFrame(y_train)
train = pd.concat([dfXtrain,dfytrain], axis=1)
test = pd.concat([dfXtest,dfytest], axis=1)

#STEP 5: Saving the datasets as a CSV (commented out to prevent remaking of a file)
#train.to_csv('DS1-train.csv', sep=',')
#test.to_csv('DS1-test.csv', sep=',')
