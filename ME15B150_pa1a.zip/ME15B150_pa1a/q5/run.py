#STEP 0: Importing Relevant Libraries
import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression


#STEP 1: Importing the Data Set and Cleaning it Up

df = pd.read_csv('../Datasets/communities.data', header=None)
df.drop(df.columns[[0,1,2,3,4]],axis=1,inplace=True)
df = df.replace('?', np.nan)
df = df.fillna(df.median(), inplace=True)

#STEP 2: Test Train Split

#defining a label and training set for the model
y = df.iloc[:,-1]
del df[127]
X = df

X_train1, X_test1, y_train1, y_test1 = train_test_split(X,y, test_size=0.2, random_state=43)
X_train2, X_test2, y_train2, y_test2 = train_test_split(X,y, test_size=0.2, random_state=44)
X_train3, X_test3, y_train3, y_test3 = train_test_split(X,y, test_size=0.2, random_state=48)
X_train4, X_test4, y_train4, y_test4 = train_test_split(X,y, test_size=0.2, random_state=46)
X_train5, X_test5, y_train5, y_test5 = train_test_split(X,y, test_size=0.2, random_state=47)

#STEP 3: Linear Regression

linreg = LinearRegression()
linreg.fit(X_train1,y_train1)
y_predict1 = linreg.predict(X_test1)
linreg.fit(X_train2,y_train2)
y_predict2 = linreg.predict(X_test2)
linreg.fit(X_train3,y_train3)
y_predict3 = linreg.predict(X_test3)
linreg.fit(X_train4,y_train4)
y_predict4 = linreg.predict(X_test4)
linreg.fit(X_train5,y_train5)
y_predict5 = linreg.predict(X_test5)

print "Linear Regression:"
print "Case 1, RSS = " + str(np.linalg.norm(y_test1-y_predict1)**2)
print "Case 2, RSS = " + str(np.linalg.norm(y_test2-y_predict2)**2)
print "Case 3, RSS = " + str(np.linalg.norm(y_test3-y_predict3)**2)
print "Case 4, RSS = " + str(np.linalg.norm(y_test4-y_predict4)**2)
print "Case 5, RSS = " + str(np.linalg.norm(y_test5-y_predict5)**2)
print "Average =" + str(np.mean([(np.linalg.norm(y_test1-y_predict1)**2),(np.linalg.norm(y_test2-y_predict2)**2),(np.linalg.norm(y_test3-y_predict3)**2),(np.linalg.norm(y_test4-y_predict4)**2),(np.linalg.norm(y_test5-y_predict5)**2)]))
