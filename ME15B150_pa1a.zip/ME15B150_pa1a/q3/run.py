#STEP 0: Importing Relevant Libraries

import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
import sklearn.metrics as met 
from sklearn.neighbors import KNeighborsClassifier

#STEP 1: Uploading DataSets

X_train = pd.read_csv('../Datasets/DS1-train.csv')
X_test = pd.read_csv('../Datasets/DS1-test.csv')

y_train = X_train.iloc[:,-1]
y_test = X_test.iloc[:,-1]
del X_train['0.1']
del X_test['0.1']

#STEP 2: KNN Classification

neigh = KNeighborsClassifier(n_neighbors=1)
neigh.fit(X_train,y_train)
y_predict_knn = neigh.predict(X_test)

#STEP 3: Finding the Best K for the given Data and Finding the Value of K

accuracy = []
for i in range(1,400):
	neigh = KNeighborsClassifier(n_neighbors=i)
	neigh.fit(X_train,y_train)
	y_predict_knn = neigh.predict(X_test)	
	accuracy.append(met.accuracy_score(y_test,y_predict_knn))
k_max = np.argmax(accuracy)
print "Using accuracy as a metric, the best value of K is" + str(k_max+1)
print "K Nearest Neighbors Classification for the best K is :"
neigh = KNeighborsClassifier(n_neighbors=k_max+1)
neigh.fit(X_train,y_train)
y_predict_knn = neigh.predict(X_test)
print "Accuracy: " + str(met.accuracy_score(y_test,y_predict_knn))
print "Precision: " + str(met.precision_score(y_test,y_predict_knn))
print "Recall Score: " + str(met.recall_score(y_test,y_predict_knn))
print "F-Measure: " + str(met.f1_score(y_test,y_predict_knn))