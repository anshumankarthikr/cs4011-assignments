#STEP 0: Importing Relevant Libraries

import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
import sklearn.metrics as met 

#STEP 1: Defining Relevant Functions

def discriminant(weights,vect):
	if((np.dot(weights,vect))>0):
		return 1
	else:
		return -1

#STEP 2: Uploading DataSets

X_train = pd.read_csv('../Datasets/DS1-train.csv')
X_test = pd.read_csv('../Datasets/DS1-test.csv')

y_train = X_train.iloc[:,-1]
y_test = X_test.iloc[:,-1]
del X_train['0.1']
del X_test['0.1']

X_train = X_train.as_matrix()
X_test = X_test.as_matrix()
y_train = y_train.as_matrix()
y_test = y_test.as_matrix()

#STEP 3: Linear Regression
pseudo_inv = np.linalg.pinv(X_train)
weights = np.dot(pseudo_inv,y_train)

y_predict_linearreg = []

for i in X_test:
	y_predict_linearreg.append(discriminant(weights,i))

#np.savetxt("coeffs.csv",weights, delimiter=",") (commenting this out to prevent rewriting)

#STEP 4: Printing Relevant Scores
print "Linear Regression Classification:"
print "Accuracy: " + str(met.accuracy_score(y_test,y_predict_linearreg))
print "Precision: " + str(met.precision_score(y_test,y_predict_linearreg))
print "Recall Score: " + str(met.recall_score(y_test,y_predict_linearreg))
print "F-Measure: " + str(met.f1_score(y_test,y_predict_linearreg))
