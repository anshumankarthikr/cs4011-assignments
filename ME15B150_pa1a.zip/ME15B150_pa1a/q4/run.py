#STEP 0: Importing Relevant Libraries
import numpy as np 
import pandas as pd 

#STEP 1: Importing the Data Set and Cleaning it Up

df = pd.read_csv('../Datasets/communities.data', header=None)
df.drop(df.columns[[0,1,2,3,4],axis=1,inplace=True) #dropping the non=predictive columns
df = df.replace('?', np.nan) #replacing unknown data with nans
df = df.fillna(df.median(), inplace=True) # replacing nans with the median of the data

#filling with the median instead of the mean
