#Importing Relevant Libraries
from math import exp
from random import seed
from random import random
import random
import numpy as np
from numpy import linalg as LA
import pandas as pd
import math
import sklearn.preprocessing as preproc
import sklearn.metrics as met 

#Reading the data and converting it to usable forms
X_train = pd.read_csv('../Datasets/Train_features')
X_train  = X_train.as_matrix()
X_train = np.reshape(X_train,(1006,96))
X_train = preproc.scale(X_train)
y_train = pd.read_csv('../Datasets/Train_labels')
y_train = y_train.as_matrix()
X_test = pd.read_csv('../Datasets/Test_features')
X_test  = X_test.as_matrix()
X_test = np.reshape(X_test,(80,96))
X_test = preproc.scale(X_test)
y_test = pd.read_csv('../Datasets/Test_labels')
y_test = y_test.as_matrix()

y_train_matrix = []
for row in y_train:
	if row[0] == 1:
		y_train_matrix.append([1,0,0,0])
	if row[0] == -1:
		y_train_matrix.append([0,1,0,0])
	if row[0] == 2:
		y_train_matrix.append([0,0,1,0])
	if row[0] == -2:
		y_train_matrix.append([0,0,0,1])

y_train = np.mat(y_train_matrix)

y_train_matrix = []
for row in y_test:
	if row[0] == 1:
		y_train_matrix.append(1)
	if row[0] == -1:
		y_train_matrix.append(-1)
	if row[0] == 2:
		y_train_matrix.append(2)
	if row[0] == -2:
		y_train_matrix.append(-2)

y_test = y_train_matrix
#Firstly, we initialize the neural network by choosing random weights. 
#We do not assume any of the hyperparameters and generalize for hidden layer,etc.
def initialization(n_inputs, n_hidden, n_outputs):
	network = []
	hidden_layer = [{'weights':np.array([(random.normalvariate(0,0.08)) for i in range(n_inputs + 1)])} for i in range(n_hidden)]
	network.append(hidden_layer)
	output_layer = [{'weights':np.array([(random.normalvariate(0,0.08)) for i in range(n_hidden + 1)])} for i in range(n_outputs)]
	network.append(output_layer)
	return network

#Now we define activation for a neuron

def activate(weights, inputs):
	activation = weights[-1]
	for i in range(len(weights)-1):
		activation += weights[i]*inputs[i]
	return activation 

# We now define the transfer function as well as the softmax function. 

def transfer(a):
	if a < 0:
		return (1-(1/(1+math.exp(a))))
	else:
		return 1/(1+math.exp(-a))

def softmax(x):
    """Compute softmax values for each sets of scores in x."""
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()

#Now,we define the forward propagation methodology, using the above general construct of 
#neural network. This will return the outputs of the neural network with a given set of weights

def forward_propagation(network, row):
	inputs = row
	for layer in network:
		new_inputs = []
		for neuron in layer:
			activation = activate(neuron['weights'], inputs)
			neuron['output'] = transfer(activation)
			new_inputs.append(neuron['output'])
		inputs = new_inputs
	return inputs

#Now we calculate the error for a given set of weights and define derivatives as "deltas"

def back_propagation_error(network, y_test):
	for i in reversed(range(len(network))):
		layer = network[i]
		errors = list()
		if i != len(network)-1:
			for j in range(len(layer)):
				error = 0.0
				for neuron in network[i + 1]:
					error += (neuron['weights'][j] * neuron['delta'])
				errors.append(error)
		else:
			for j in range(len(layer)):
				neuron = layer[j]
				errors.append(LA.norm(y_test[j] - softmax(neuron['output'])))
		for j in range(len(layer)):
			neuron = layer[j]
			neuron['delta'] = errors[j] * transfer_derivative(neuron['output'])
			

# Now we write gradient descent to update the neural network for a given set of weights

def grad_descent_update(network,row, eta):
	# for every neuron ni in input layer:
	#	for every neuron nj in hidden layer:
	# 		w[i][j] = w[i][j] - eta * out(ni) * delta(nj)
	
	for i in range(len(network)):
		inputs = row[:-1]
		if i != 0:
			inputs = [neuron['output'] for neuron in network[i - 1]]
		for neuron in network[i]:
			for j in range(len(inputs)):
				neuron['weights'][j] += eta * neuron['delta'] * inputs[j]
			neuron['weights'][-1] += eta* neuron['delta']

# Now we write gradient descent to update the weights in the case of a regularized neural network
def grad_descent_update_reg(network,row,eta,gamma):
	for i in range(len(network)):
		inputs = row[:-1]
		if i != 0:
			inputs = [neuron['output'] for neuron in network[i - 1]]
		for neuron in network[i]:
			for j in range(len(inputs)):
				neuron['weights'][j] += (eta *((neuron['delta'] * inputs[j]) - gamma*neuron['weights'][j]))
			neuron['weights'][-1] += (eta*((neuron['delta'] - gamma*neuron['weights'][-1])))

#We write the train function for the weights in the case of non-regularized error. 

def train_network(network, train, eta, n_epoch, n_outputs):
	for epoch in range(n_epoch):
		y_predict = []
		sum_error = 0.0
		count = 0
		for row in train:
			output = forward_propagation(network, row)
			sum_error += (LA.norm(y_train[count]-softmax(output)))**2
			back_propagation_error(network, y_train)
			grad_descent_update(network, row, eta)
			count=count+1
		sum=0
		for i in range(80):
			output_probab = forward_propagation(network,X_test[i,:])
			pred_class = np.argmax(softmax(output_probab))
			if pred_class == 0:
				y_predict.append(1)
			if pred_class == 1:
				y_predict.append(-1)
			if pred_class == 2:
				y_predict.append(2)
			if pred_class == 3:
				y_predict.append(-2)
		print('epoch=%d, learning rate=%.3f, error=%.3f' % (epoch, eta, sum_error))
		print "Neural Network Classification (no regularization):"
		print "Accuracy: " + str(met.accuracy_score(y_test,y_predict))
		print "Precision: " + str(met.precision_score(y_test,y_predict,average='macro',pos_label=-2))
		print "Recall Score: " + str(met.recall_score(y_test,y_predict,average='macro',pos_label=-2))
		print "F-Measure: " + str(met.f1_score(y_test,y_predict,average='macro',pos_label=-2))

# We now define the train network function for the regularized loss case.
def train_network_reg(network, train, eta, n_epoch, n_outputs, gamma):
	for epoch in range(n_epoch):
		y_predict = []
		sum_error = 0.0
		count = 0
		for row in train:
			output = forward_propagation(network, row)
			sum_error += (LA.norm(y_train[count]-softmax(output)))**2
			back_propagation_error(network, y_train)
			grad_descent_update_reg(network, row, eta, gamma)
			count=count+1
		sum=0
		for i in range(80):
			output_probab = forward_propagation(network,X_test[i,:])
			pred_class = np.argmax(softmax(output_probab))
			if pred_class == 0:
				y_predict.append(1)
			if pred_class == 1:
				y_predict.append(-1)
			if pred_class == 2:
				y_predict.append(2)
			if pred_class == 3:
				y_predict.append(-2)
		print('epoch=%d, learning rate=%.3f, error=%.3f' % (epoch, eta, sum_error))
		print "Neural Network Classification (with regularization):"
		print "Accuracy: " + str(met.accuracy_score(y_test,y_predict))
		print "Precision: " + str(met.precision_score(y_test,y_predict,average='macro',pos_label=-2))
		print "Recall Score: " + str(met.recall_score(y_test,y_predict,average='macro',pos_label=-2))
		print "F-Measure: " + str(met.f1_score(y_test,y_predict,average='macro',pos_label=-2))
		
#We now train and test the network as per our data specifications.
n_inputs = len(X_train[0]) 
n_outputs = 4
network = initialization(n_inputs, 50, n_outputs)
#train_network_reg(network, X_train,0.01,5000,n_outputs
train_network_reg(network, X_train, 0.01, 5000, n_outputs,100)




