
import pandas as pd 
from sklearn.linear_model import LogisticRegression
import sklearn.metrics as met
import numpy as np
X_train = pd.read_csv('../Datasets/Train_features2')
X_train  = X_train.as_matrix()
X_train = np.reshape(X_train,(518,96))
y_train = pd.read_csv('../Datasets/Train_labels2')
y_train = y_train.as_matrix()
X_test = pd.read_csv('../Datasets/Test_features2')
X_test  = X_test.as_matrix()
X_test = np.reshape(X_test,(40,96))
y_test = pd.read_csv('../Datasets/Test_labels2')
y_test = y_test.as_matrix()

logreg = LogisticRegression(C=10000) 
logreg.fit(X_train,y_train)
y_predict = logreg.predict(X_test)

print "Logistic Regression Classification (no regularization): "
print "Accuracy: " + str(met.accuracy_score(y_test,y_predict))
print "Precision:" + str(met.precision_score(y_test,y_predict,pos_label=1))
print "Recall Score: " + str(met.recall_score(y_test,y_predict,pos_label=1))
print "F-Measure: " + str(met.f1_score(y_test,y_predict,pos_label=1))









 


























