import os
import numpy as np 
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
import sklearn.metrics as met
from sklearn.metrics import precision_recall_curve
import matplotlib.pyplot as plt
from scipy.stats import dirichlet
import sklearn.metrics as met 

VOCAB_SIZE = 25000
EPSILON = 1e-6
ALPHA = sampl = np.random.uniform(low=0.5, high=1.0, size=(VOCAB_SIZE,))

X_train = np.zeros((878,VOCAB_SIZE))
y_train = np.zeros((878))
counter = 0
for foldername  in os.listdir('../Datasets/spam_train_1'):
    try:                                                                   
        for filename in os.listdir('../Datasets/spam_train_1/' + foldername):                   
            lines = open('../Datasets/spam_train_1/' +  foldername + '/' + filename).readlines()                                                                      
            vocab_size = 0           
            matrix_of_strings = [l.split() for l in lines]
            for row in matrix_of_strings:                   
                for number_as_string in row:
                    try:
                        feature = int(number_as_string)
                        X_train[counter,feature] += 1 
                        vocab_size = max(vocab_size, feature) 
                    except ValueError: 
                        pass
            if 'legit' in filename:
                y_train[counter] = 1
            else:
                y_train[counter] = 0                     
            counter = counter + 1 
    except OSError:                   
        pass 

X_test = np.zeros((221,VOCAB_SIZE))
y_test = np.zeros((221))

counter = 0
for foldername  in os.listdir('../Datasets/spam_test_1'):
    try:                                                                   
        for filename in os.listdir('../Datasets/spam_test_1/' + foldername):                   
            lines = open('../Datasets/spam_test_1/' +  foldername + '/' + filename).readlines()                                                                      
            vocab_size = 0           
            matrix_of_strings = [l.split() for l in lines]
            for row in matrix_of_strings:                   
                for number_as_string in row:
                    try:
                        feature = int(number_as_string)
                        X_test[counter,feature] += 1 
                        vocab_size = max(vocab_size, feature) 
                    except ValueError: 
                        pass
            if 'legit' in filename:
                y_test[counter] = 1
            else:
                y_test[counter] = 0                     
            counter = counter + 1 
    except OSError:                   
        pass 

#constructing multinomial estimations using the multinomial

spam_labels = []
legit_labels = []

for i in range(878):
    if y_train[i] == 0:
        spam_labels.append(i)
    if y_train[i] == 1:
        legit_labels.append(i)


spam_numbers = np.zeros(VOCAB_SIZE)
legit_numbers = np.zeros(VOCAB_SIZE)

for i in legit_labels:
    legit_numbers += X_train[i]


for i in spam_labels:
    spam_numbers += X_train[i]

mle_estimates_spam = []
mle_estimates_legit = []
mle_estimates_spam_bernoulli = []
mle_estimates_legit_bernoulli = []
mle_estimates_spam_dirchlet = []
mle_estimates_legit_dirchlet = []

for i in range(VOCAB_SIZE):
    count_spam = 0
    count_legit = 0
    spam_total = len(spam_labels)
    legit_total = len(legit_labels)
    for j in spam_labels:   
        if X_train[j,i] != 0:
            count_spam = count_spam + 1
    mle_estimates_spam_bernoulli.append(float(count_spam+1)/float(spam_total+2))
    for j in legit_labels:   
        if X_train[j,i] != 0:
            count_legit = count_legit + 1
    mle_estimates_legit_bernoulli.append(float(count_legit+1)/float(legit_total+2))    

for i in range(VOCAB_SIZE):
    spam_total = len(spam_labels) 
    legit_total = len(legit_labels)
    spam_temp = (spam_numbers[i]/np.sum(spam_numbers))
    legit_temp = (legit_numbers[i]/np.sum(legit_numbers))
    mle_estimates_legit.append(legit_temp)
    mle_estimates_spam.append(spam_temp)

for i in range(VOCAB_SIZE):
    spam_total = len(spam_labels) 
    legit_total = len(legit_labels)
    spam_temp = ((spam_numbers[i]+ALPHA[i]-1)/(np.sum(spam_numbers)+np.sum(ALPHA)-VOCAB_SIZE))
    legit_temp = ((legit_numbers[i]+ALPHA[i]-1)/(np.sum(legit_numbers)+np.sum(ALPHA)-VOCAB_SIZE))
    mle_estimates_legit_dirchlet.append(legit_temp)
    mle_estimates_spam_dirchlet.append(spam_temp)

for i in range(VOCAB_SIZE):
    if mle_estimates_legit[i] == 0:
        mle_estimates_legit[i] = 1/np.sum(legit_numbers)
    if mle_estimates_spam[i] == 0:
        mle_estimates_spam[i] = 1/np.sum(spam_numbers)

for i in range(VOCAB_SIZE):
    if mle_estimates_legit_dirchlet[i] == 0:
        mle_estimates_legit_dirchlet[i] = 1/np.sum(legit_numbers)
    if mle_estimates_spam[i] == 0:
        mle_estimates_spam_dirchlet[i] = 1/np.sum(spam_numbers)

# bayesian classfiication for given test data - Numerical Instabilities Accounted for

def log_fact(N):
    res = 0
    while N > 0:
        res += np.log(N)
        N -= 1
    return res

def multinomial_predictor(document):
    log_spam_probab=np.log(float(len(spam_labels))/float((len(spam_labels)+len(legit_labels))))
    log_legit_probab=np.log(float(len(legit_labels))/float((len(spam_labels)+len(legit_labels))))
    for i in range(VOCAB_SIZE):
            log_spam_probab += (document[i] * np.log(mle_estimates_spam[i]))
            log_legit_probab += (document[i] * np.log(mle_estimates_legit[i]))
    # spam_proabab = (np.prod(np.power(mle_estimates_spam,document)))*len(spam_labels)
    # legit_proabab = (np.prod(np.power(mle_estimates_legit,document)))*len(legit_labels)
    if (log_spam_probab/(log_legit_probab)) >1:
        return 1
    else:
        return 0


def bernoulli_predictor(document):
    log_spam_probab=np.log(float(len(spam_labels))/float((len(spam_labels)+len(legit_labels))))
    log_legit_probab=np.log(float(len(legit_labels))/float((len(spam_labels)+len(legit_labels))))
    for i in range(VOCAB_SIZE):
        if document[i]!= 0:
            log_spam_probab += np.log(mle_estimates_spam_bernoulli[i])
            log_legit_probab += np.log(mle_estimates_legit_bernoulli[i])
        else:
            log_spam_probab += np.log(1-mle_estimates_spam_bernoulli[i])
            log_legit_probab += np.log(1-mle_estimates_spam_bernoulli[i])

         # spam_proabab = (np.prod(np.power(mle_estimates_spam,document)))*len(spam_labels)
     # legit_proabab = (np.prod(np.power(mle_estimates_legit,document)))*len(legit_labels)
    if (log_spam_probab/(log_legit_probab)) >1:
        return 1
    else:
        return 0    


def dirchlet_predictor(document,thresh):
# we found the prediction function for the bernoulli distribution. Now, if we model a beta prior, we get a beta output
# the parameters for the spam class is the number of documents that are spam & the number that aren't. We put in our
# calculated value of theta as the
    log_spam_probab=0
    for i in range(VOCAB_SIZE):
            log_spam_probab += (document[i] * np.log(mle_estimates_spam_dirchlet[i]))
    # spam_proabab = (np.prod(np.power(mle_estimates_spam,document)))*len(spam_labels)
    # legit_proabab = (np.prod(np.power(mle_estimates_legit,document)))*len(legit_labels)
    if np.exp(log_spam_probab)>=thresh:
        return 0
    else:
        return 1

y_predict_bernoulli = np.zeros(221)
y_predict_multinomial = np.zeros(221)
y_predict_dirchlet = np.zeros(221)

for i in range(221):
    y_predict_bernoulli[i] = bernoulli_predictor(X_test[i])

for i in range(221):
    y_predict_multinomial[i] = multinomial_predictor(X_test[i])

precision = []
recall = []

for j in range(1000):
    for i in range(221):
        y_predict_dirchlet[i] = dirchlet_predictor(X_test[i],(float(i)/1000))
    precision.append(met.precision_score(y_test,y_predict_dirchlet,labels=0))
    recall.append(met.recall_score(y_test,y_predict_dirchlet,labels=0))


mnb = MultinomialNB()
bnb = BernoulliNB()

mnb.fit(X_train,y_train)
bnb.fit(X_train,y_train)

bnb_probab = bnb.predict_proba(X_test)
mnb_probab = mnb.predict_proba(X_test)

plt.plot(precision,recall)
plt.show()





